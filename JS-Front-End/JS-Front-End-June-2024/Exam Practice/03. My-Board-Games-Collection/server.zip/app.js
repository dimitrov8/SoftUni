const baseUrl = `http://localhost:3030/jsonstore/games`;

const loadButton = document.getElementById('load-games');
const gamesList = document.getElementById('games-list');
const addButton = document.getElementById('add-game');
const editButton = document.getElementById('edit-game');
const gameNameInput = document.getElementById('g-name');
const typeInput = document.getElementById('type');
const maxPlayersInput = document.getElementById('players');

loadButton.addEventListener('click', loadGames);
addButton.addEventListener('click', handleAddGame);

async function loadGames() {
  console.log('Games Loaded:');

  const response = await fetch(baseUrl);
  const games = await response.json();
  gamesList.innerHTML = '';

  Object.values(games).forEach((game) => {
    console.log(game);

    const gameElement = createGameElement(
      game.name,
      game.type,
      game.players,
      game._id
    );

    gamesList.append(gameElement);
  });
}

function createGameElement(name, type, players, gameId) {
  const pNameElement = document.createElement('p');
  pNameElement.textContent = name;

  const pTypeElement = document.createElement('p');
  pTypeElement.textContent = type;

  const pPlayersElement = document.createElement('p');
  pPlayersElement.textContent = players;

  const divContentElement = document.createElement('div');
  divContentElement.classList.add('content');
  divContentElement.append(pNameElement, pPlayersElement, pTypeElement);

  const changeBtnElement = document.createElement('button');
  changeBtnElement.classList.add('change-btn');
  changeBtnElement.dataset.gameId = gameId;
  changeBtnElement.textContent = 'Change';
  changeBtnElement.addEventListener('click', async () => {
    await handleEdit(gameId);
  });

  const deleteBtnElement = document.createElement('button');
  deleteBtnElement.classList.add('delete-btn');
  deleteBtnElement.dataset.gameId = gameId;
  deleteBtnElement.textContent = 'Delete';
  deleteBtnElement.addEventListener('click', async () => {
    await handleDelete(gameId);
  });

  const divButtonsContainerElement = document.createElement('div');
  divButtonsContainerElement.classList.add('buttons-container');
  divButtonsContainerElement.append(changeBtnElement, deleteBtnElement);

  const divBoardGameElement = document.createElement('div');
  divBoardGameElement.classList.add('board-game');
  divBoardGameElement.append(divContentElement, divButtonsContainerElement);

  return divBoardGameElement;
}

async function handleAddGame() {
  if (isValidInput()) {
    const gameData = {
      name: gameNameInput.value,
      type: typeInput.value,
      players: maxPlayersInput.value,
    };

    await fetch(baseUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(gameData),
    });

    clearInputs();
    await loadGames();
  }
}

async function handleEdit(gameId) {
  const game = await getGameById(gameId);

  populateInputs(game);

  addButton.setAttribute('disabled', true);
  editButton.removeAttribute('disabled');

  editButton.addEventListener('click', editGame);

  async function editGame() {
    if (isValidInput()) {
      await fetch(`${baseUrl}/${gameId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          name: gameNameInput.value,
          type: typeInput.value,
          players: maxPlayersInput.value,
          _id: gameId,
        }),
      });

      clearInputs();

      await loadGames();

      editButton.setAttribute('disabled', true);
      addButton.removeAttribute('disabled');
    }
  }
}

function populateInputs(game) {
  gameNameInput.value = game.name;
  typeInput.value = game.type;
  maxPlayersInput.value = game.players;
}

function clearInputs() {
  gameNameInput.value = '';
  typeInput.value = '';
  maxPlayersInput.value = '';
}

async function handleDelete(gameId) {
  await fetch(`${baseUrl}/${gameId}`, {
    method: 'DELETE',
  });

  await loadGames();
}

async function getGameById(gameId) {
  const response = await fetch(`${baseUrl}/${gameId}`);

  return await response.json();
}

function isValidInput() {
  return (
    gameNameInput.value !== '' &&
    typeInput.value !== '' &&
    maxPlayersInput.value !== ''
  );
}
